"""Animated: an agent pipeline running step by step, most runs cascading to failure."""
import sys, pathlib
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation, PillowWriter
from matplotlib.patches import FancyBboxPatch, Circle, FancyArrowPatch
ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from viz.style import *  # noqa
GOODC=GOOD; BADC=AGGRESSIVE; BLUE=RESTRAINED

def main():
    N_LANES=10; N_STEPS=10; P=0.85
    rng=np.random.default_rng(5)
    # precompute each lane's fate: step at which it fails (or survives)
    fail_step=np.full(N_LANES,N_STEPS+1)
    for L in range(N_LANES):
        for s in range(N_STEPS):
            if rng.random()>=P:
                fail_step[L]=s; break

    fig=plt.figure(figsize=(8.2,4.8),facecolor=BG,dpi=100)
    fig.text(0.06,0.93,"Ten AI 'employees' attempt the same 10-step job",fontsize=14.5,fontweight="semibold",color=INK)
    fig.text(0.06,0.875,"Each step succeeds 85% of the time. Watch how few runs make it all the way.",fontsize=9.3,color=SUB)
    fig.text(0.06,0.05,"Source: agentco simulation by the author. 85% per step, 10 steps -> ~20% finish.",fontsize=8,color=FAINT)
    ax=fig.add_axes([0.06,0.16,0.72,0.66]); ax.set_xlim(0,N_STEPS+1); ax.set_ylim(-0.5,N_LANES-0.5)
    ax.axis("off"); ax.invert_yaxis()
    # step headers
    for s in range(N_STEPS):
        ax.text(s+1,-0.9,f"{s+1}",ha="center",fontsize=8,color=SUB)
    ax.text((N_STEPS+1)/2,N_LANES-0.2,"process step ->",ha="center",fontsize=8.5,color=SUB)
    cells=[[None]*N_STEPS for _ in range(N_LANES)]
    for L in range(N_LANES):
        for s in range(N_STEPS):
            c=FancyBboxPatch((s+0.62,L-0.32),0.76,0.64,boxstyle="round,pad=0,rounding_size=0.1",
                             fc="#E3E9F1",ec="white",lw=1,zorder=3)
            ax.add_patch(c); cells[L][s]=c
    counter=fig.text(0.80,0.55,"",fontsize=11,color=INK,fontweight="semibold",va="top")

    frames=N_STEPS+6
    def update(f):
        alive=0; dead=0; done=0
        for L in range(N_LANES):
            for s in range(N_STEPS):
                if s< f:
                    if s<fail_step[L]:
                        cells[L][s].set_facecolor(GOODC)  # passed
                    elif s==fail_step[L]:
                        cells[L][s].set_facecolor(BADC)    # failed here
                    else:
                        cells[L][s].set_facecolor("#F0D9D4")  # abandoned after failure
            # tally at current frame
            if fail_step[L]>N_STEPS:
                if f>=N_STEPS: done+=1
        # count
        finished=int(np.sum(fail_step>N_STEPS))
        failed_so_far=int(np.sum(fail_step< min(f,N_STEPS)))
        step_txt=min(f,N_STEPS)
        counter.set_text(f"after step {step_txt}\n\n{failed_so_far}/10 runs\nhave failed"+
                         (f"\n\n{finished}/10 finished" if f>=N_STEPS else ""))
        return []
    anim=FuncAnimation(fig,update,frames=frames,blit=False)
    out=ROOT/"figures/anim_cascade.gif"
    anim.save(out,writer=PillowWriter(fps=2),savefig_kwargs={"facecolor":BG})
    print(out)

if __name__=="__main__":
    main()
