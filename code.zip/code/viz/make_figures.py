"""Figures for the AI-agent-workforce article, on the shared light theme."""
import json, sys, pathlib
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle, Rectangle

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from viz.style import *  # noqa

R = ROOT / "results"
GOODC = GOOD
BADC = AGGRESSIVE
MIDC = PASSIVE
BLUE = RESTRAINED


def fig_cliff():
    j = json.load(open(R / "company.json"))["e1_cliff"]
    steps = np.array(j["steps"])
    fig, gs = card(9.2, 5.2,
                   "The reliability cliff every AI startup falls off",
                   "End-to-end success of a multi-step process, when each step is handled by an agent of a given "
                   "accuracy. Errors multiply.",
                   "Source: agentco Monte-Carlo simulation by the author (40,000 trials/point), matching 2026 "
                   "field data (0.85^10 = 20%).",
                   top=0.73, bottom=0.14, left=0.09, right=0.80)
    ax = style_ax(fig.add_subplot(GridSpec(1, 1, figure=fig, **gs)[0]),
                  "Steps in the business process", "End-to-end success rate")
    colors = {"0.99": GOODC, "0.95": BLUE, "0.9": MIDC, "0.85": "#E07A56", "0.8": BADC}
    labels = {"0.99": "99% per step", "0.95": "95%", "0.9": "90%", "0.85": "85%", "0.8": "80%"}
    for p in ["0.99", "0.95", "0.9", "0.85", "0.8"]:
        v = np.array(j["curves"][p]) * 100
        ax.plot(steps, v, color=colors[p], lw=2.5)
        end_label(ax, steps[-1], v[-1], labels[p], colors[p], dy=0)
    # highlight the 85%/10-step point
    y85 = j["curves"]["0.85"][9] * 100
    ax.scatter([10], [y85], s=70, color="#E07A56", zorder=6, edgecolors=CARD, linewidths=1.5)
    ax.annotate(f"a '10-step employee'\nat 85% works {y85:.0f}% of the time",
                xy=(10, y85), xytext=(11.5, 55), fontsize=9, color=INK,
                arrowprops=dict(arrowstyle="-|>", color=FAINT, lw=1.2))
    ax.axhspan(0, 50, color=BADC, alpha=0.04, lw=0)
    ax.set_xlim(1, 20); ax.set_ylim(0, 100); ax.set_xticks([1, 5, 10, 15, 20])
    ax.set_yticks([0, 25, 50, 75, 100], ["0", "25%", "50%", "75%", "100%"])
    return save(fig, "cliff.png")


def fig_fixes():
    j = json.load(open(R / "company.json"))["e2_fixes"]
    fig, gs = card(9.2, 5.0,
                   "You don't fix this with a smarter model. You fix it with architecture.",
                   "The same 10-step, 85%-per-step process, rescued step by step by how it's engineered, not by the AI.",
                   "Source: agentco simulation by the author, 40,000 trials per bar.",
                   top=0.74, bottom=0.16, left=0.26, right=0.93)
    ax = style_ax(fig.add_subplot(GridSpec(1, 1, figure=fig, **gs)[0]),
                  "End-to-end success rate", "")
    ax.grid(axis="y", visible=False); ax.grid(axis="x", visible=True)
    names = [f["name"] for f in j]
    vals = [f["success"] * 100 for f in j]
    y = np.arange(len(names))[::-1]
    cols = [BADC if v < 30 else (MIDC if v < 70 else GOODC) for v in vals]
    ax.barh(y, vals, height=0.62, color=cols, zorder=3)
    for yy, v in zip(y, vals):
        ax.text(v + 1.5, yy, f"{v:.0f}%", va="center", fontsize=10.5, fontweight="semibold", color=INK)
    ax.set_yticks(y, names); ax.tick_params(axis="y", labelsize=10, labelcolor=INK)
    ax.set_xlim(0, 105); ax.set_xticks([0, 25, 50, 75, 100], ["0", "25%", "50%", "75%", "100%"])
    return save(fig, "fixes.png")


def fig_where_die():
    j = json.load(open(R / "company.json"))["e3_where_die"]
    fig, gs = card(9.2, 4.8,
                   "Most runs die young, and quietly",
                   "Out of 40,000 attempts at a 10-step process (85% per step), where each run first failed. "
                   "Only a fifth finished.",
                   "Source: agentco simulation by the author.",
                   top=0.75, bottom=0.14, left=0.09, right=0.78)
    ax = style_ax(fig.add_subplot(GridSpec(1, 1, figure=fig, **gs)[0]),
                  "Step where the run first failed", "Share of all runs")
    ax.grid(axis="x", visible=False)
    steps = np.arange(1, 11)
    fails = np.array(j["fail_at_step"]) / j["total"] * 100
    ax.bar(steps, fails, width=0.7, color=BADC, alpha=0.85, zorder=3)
    surv = j["survived"] / j["total"] * 100
    ax.bar([11.3], [surv], width=0.7, color=GOODC, zorder=3)
    ax.text(11.3, surv + 1, f"{surv:.0f}%", ha="center", fontsize=10, fontweight="semibold", color=GOOD)
    ax.text(11.3, -3.2, "finished", ha="center", fontsize=8.5, color=GOOD, fontweight="semibold")
    ax.annotate("every step is another\nchance to fall over", xy=(3, fails[2]), xytext=(5, 12),
                fontsize=9, color=SUB, arrowprops=dict(arrowstyle="-|>", color=FAINT, lw=1))
    ax.set_xticks(list(steps) + [11.3], [str(s) for s in steps] + ["done"])
    ax.set_xlim(0.3, 12.2); ax.set_ylim(0, 16)
    ax.set_yticks([0, 5, 10, 15], ["0", "5%", "10%", "15%"])
    return save(fig, "where_die.png")


def fig_required():
    j = json.load(open(R / "company.json"))["e4_required"]
    steps = np.array(j["steps"])
    fig, gs = card(9.2, 4.8,
                   "The accuracy you'd actually need is almost inhuman",
                   "Per-step accuracy required to hit a reliable end-to-end result, as the process gets longer. "
                   "Today's agents sit near 85%.",
                   "Source: author's calculation (target^(1/steps)). Today's per-step reliability from 2026 benchmarks.",
                   top=0.74, bottom=0.14, left=0.09, right=0.80)
    ax = style_ax(fig.add_subplot(GridSpec(1, 1, figure=fig, **gs)[0]),
                  "Steps in the process", "Required per-step accuracy")
    for target, col, lab, dy in [("0.99", AGGRESSIVE, "for 99% reliable", 5), ("0.95", RESTRAINED, "for 95% reliable", -6)]:
        v = np.array(j[target]) * 100
        ax.plot(steps, v, color=col, lw=2.5)
        end_label(ax, steps[-1], v[-1], lab, col, dy=dy)
    ax.axhline(85, color=MIDC, lw=1.6, ls=(0, (4, 3)))
    ax.text(1, 86, "where today's agents are (~85%)", color="#9A6A00", fontsize=9, fontweight="semibold")
    ax.fill_between(steps, 85, 100, color=GOOD, alpha=0.04)
    ax.set_xlim(1, 20); ax.set_ylim(80, 100.5); ax.set_xticks([1, 5, 10, 15, 20])
    ax.set_yticks([80, 85, 90, 95, 100], ["80%", "85%", "90%", "95%", "100%"])
    return save(fig, "required.png")


def fig_concept():
    fig, gs = card(9.2, 4.4,
                   "Two ways to run a company with agents",
                   "The naive chain fails if any link breaks. The engineered version contains failures with gates "
                   "and checks.",
                   "Original diagram by the author.",
                   top=0.80, bottom=0.08, left=0.05, right=0.95)
    ax = fig.add_subplot(GridSpec(1, 1, figure=fig, **gs)[0])
    ax.set_xlim(0, 12); ax.set_ylim(0, 5); ax.axis("off")

    def node(x, y, c, label=None):
        ax.add_patch(FancyBboxPatch((x-0.42, y-0.3), 0.84, 0.6, boxstyle="round,pad=0,rounding_size=0.08",
                                    fc=c, alpha=0.9, ec="white", lw=1.2, zorder=3))
        if label:
            ax.text(x, y-0.62, label, ha="center", fontsize=7.2, color=SUB)

    # naive chain
    ax.text(0.3, 4.5, "Naive chain", fontsize=11, fontweight="semibold", color=BADC)
    xs = np.linspace(1.4, 10.6, 6)
    for i, x in enumerate(xs):
        node(x, 3.7, RESTRAINED)
        if i < 5:
            ax.add_patch(FancyArrowPatch((x+0.42, 3.7), (xs[i+1]-0.42, 3.7), arrowstyle="-|>",
                                         mutation_scale=11, color=FAINT, lw=1.3))
    ax.add_patch(Circle((xs[3], 3.7), 0.30, fc="none", ec=BADC, lw=2.2, zorder=5))
    ax.annotate("one break\nkills the run", xy=(xs[3], 3.4), xytext=(xs[3], 2.75),
                ha="center", fontsize=8, color=BADC, arrowprops=dict(arrowstyle="-|>", color=BADC, lw=1.2))

    # engineered
    ax.text(0.3, 2.1, "Engineered", fontsize=11, fontweight="semibold", color=GOOD)
    for i, x in enumerate(xs):
        node(x, 1.2, RESTRAINED)
        if i < 5:
            ax.add_patch(FancyArrowPatch((x+0.42, 1.2), (xs[i+1]-0.42, 1.2), arrowstyle="-|>",
                                         mutation_scale=11, color=FAINT, lw=1.3))
        # verify tick under each
        ax.text(x, 0.65, "check", ha="center", fontsize=6.4, color=GOOD)
    for gi in (1, 3):
        ax.add_patch(Rectangle((xs[gi]-0.55, 0.5), 1.1, 1.4, fill=False, ec=GOOD, lw=1.4, ls=(0,(3,2)), zorder=4))
    ax.text(xs[1], 2.05, "human gate", ha="center", fontsize=7, color=GOOD)
    ax.text(xs[3], 2.05, "human gate", ha="center", fontsize=7, color=GOOD)
    return save(fig, "concept.png")


if __name__ == "__main__":
    for f in [fig_cliff, fig_fixes, fig_where_die, fig_required, fig_concept]:
        print(f())
