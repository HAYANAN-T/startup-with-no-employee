"""Cover: the cascade grid + title."""
import sys, pathlib
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from viz.style import *  # noqa
GOODC=GOOD; BADC=AGGRESSIVE
def main():
    N_LANES=8; N_STEPS=10; P=0.85
    rng=np.random.default_rng(11)
    fail=np.full(N_LANES,N_STEPS+1)
    for L in range(N_LANES):
        for s in range(N_STEPS):
            if rng.random()>=P: fail[L]=s; break
    fig=plt.figure(figsize=(8,4.5),facecolor="#F3F6FA")
    fig.text(0.06,0.74,"The startup with",fontsize=27,fontweight="bold",color=INK,va="center")
    fig.text(0.06,0.645,"no employees",fontsize=27,fontweight="bold",color=BADC,va="center")
    fig.text(0.06,0.48,"Everyone says AI agents are the new workforce.\nThe math says most of them quietly fall over.\nHere's what actually works.",
             fontsize=11,color=SUB,va="center",linespacing=1.5)
    fig.text(0.06,0.15,"Right: 8 AI 'workers' run a 10-step job at 85%/step. Green finished,\nred failed. Only a couple make it.",
             fontsize=7.4,color=FAINT,linespacing=1.4)
    ax=fig.add_axes([0.52,0.12,0.44,0.74]); ax.set_xlim(0,N_STEPS); ax.set_ylim(-0.5,N_LANES-0.5)
    ax.axis("off"); ax.invert_yaxis()
    for L in range(N_LANES):
        for s in range(N_STEPS):
            if s<fail[L]: c=GOODC
            elif s==fail[L]: c=BADC
            else: c="#F0D9D4"
            ax.add_patch(FancyBboxPatch((s+0.1,L-0.34),0.8,0.68,boxstyle="round,pad=0,rounding_size=0.12",
                         fc=c,ec="white",lw=1))
    fig.savefig(ROOT/"figures/cover.png",dpi=200,facecolor=fig.get_facecolor())
    print("cover.png")
if __name__=="__main__": main()
