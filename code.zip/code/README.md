# agentco

Companion code for the article **"The Startup With No Employees: What Happens When AI Agents Become the Workforce?"**

A Monte-Carlo simulation of a "zero-employee" startup run by AI agents. It
reproduces the compounding-error math behind the 2026 "agent reliability cliff"
(0.85^10 = 20%) and measures how much each architectural fix — checkpoint-and-
retry, verification gates, human-in-the-loop, bounded scope — actually rescues a
brittle multi-step process.

> **What this is.** A simulation of *reliability*, not of language. It shows why
> agents that ace a 3-step demo collapse on a 15-step business process, and what
> changes that. Every number matches the published 2026 field data.

## Quick start

```bash
pip install -r requirements.txt
python -m sim.experiment      # runs E1-E4 -> results/company.json
python viz/make_figures.py    # the charts
python viz/make_gif.py        # the cascade animation
python viz/cover.py           # the cover
```

## Layout

```
sim/
  company.py     the multi-agent company model (chain + architectural fixes)
  experiment.py  E1 cliff, E2 fix ladder, E3 where-runs-die, E4 required accuracy
viz/
  style.py, make_figures.py, make_gif.py, cover.py
```

## Headline results (from this code)

| Result | Value |
|---|---|
| 10-step process at 85%/step | ~20% end-to-end success |
| + checkpoint & retry | ~92% |
| + everything combined | ~93% |
| Per-step accuracy needed for 95% over 10 steps | 99.5% |

Matches 2026 field data: 0.85^10 = 20%, 0.95^10 = 60%, 0.85^20 = 4%.

## License

Code: MIT.
