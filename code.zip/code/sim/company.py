"""
sim.company - a Monte-Carlo model of a "zero-employee" startup run by AI agents.

A business process is a chain of steps (lead -> qualify -> draft -> send -> ...).
Each step is performed by an AI agent that succeeds with per-step probability p.
The naive pipeline just chains them: one failure anywhere ruins the run. This
reproduces the compounding-error math that the 2026 field data keeps hitting
(0.85^10 ~ 20%).

We then add the architectural fixes that actually work in production, and measure
how much each one buys:

  * checkpoint + retry : after each step, verify and retry up to r times
  * verification gate  : an independent checker catches a fraction of errors
  * human in the loop   : a human reviews at a few gates, catching most errors
  * bounded scope       : split one long chain into short, independent sub-chains

Everything is a simulation of *reliability*, not of language. It shows why the
same agents that ace a 3-step demo collapse on a 15-step business process, and
what changes that.
"""
from __future__ import annotations
import numpy as np
from dataclasses import dataclass, field


@dataclass
class Architecture:
    per_step_p: float = 0.85       # base per-step success probability
    n_steps: int = 10              # length of the business process
    retries: int = 0               # checkpoint+retry attempts per step (0 = none)
    verify_catch: float = 0.0      # fraction of a step's errors caught by a checker
    human_gates: int = 0           # number of human review gates in the chain
    human_catch: float = 0.95      # fraction of errors a human catches at a gate
    subchains: int = 1             # split into this many independent sub-chains


def _step_success(p, retries, verify_catch, rng, n):
    """Success probability of a single step given retry + verification, vectorized."""
    # base attempt
    ok = rng.random(n) < p
    # verification catches some failures and triggers a retry
    for _ in range(retries):
        caught = (~ok) & (rng.random(n) < (verify_catch if verify_catch > 0 else 1.0))
        redo = caught & (rng.random(n) < p)
        ok = ok | redo
    return ok


def run(arch: Architecture, trials: int = 20000, seed: int = 0) -> dict:
    rng = np.random.default_rng(seed)
    steps_per_chain = max(arch.n_steps // arch.subchains, 1)

    # a run succeeds only if ALL sub-chains succeed (they compose the final product)
    final_ok = np.ones(trials, dtype=bool)
    # track where failures happen for the "cascade" figure (single-chain case)
    first_fail_step = np.full(trials, -1)

    gate_positions = set()
    if arch.human_gates > 0:
        # place human gates evenly along the full process
        gate_positions = set(
            int(round((i + 1) * arch.n_steps / (arch.human_gates + 1)))
            for i in range(arch.human_gates)
        )

    global_step = 0
    for c in range(arch.subchains):
        chain_ok = np.ones(trials, dtype=bool)
        for s in range(steps_per_chain):
            global_step += 1
            ok = _step_success(arch.per_step_p, arch.retries, arch.verify_catch, rng, trials)
            # a human gate rescues most errors that slipped through
            if global_step in gate_positions:
                rescued = (~ok) & (rng.random(trials) < arch.human_catch)
                ok = ok | rescued
            newly_failed = chain_ok & (~ok)
            first_fail_step[newly_failed & (first_fail_step < 0)] = global_step
            chain_ok = chain_ok & ok
        final_ok = final_ok & chain_ok

    return {
        "success_rate": float(final_ok.mean()),
        "n_steps": arch.n_steps,
        "first_fail_step": first_fail_step,
        "final_ok": final_ok,
    }


def naive_curve(per_step_p: float, max_steps: int = 20):
    """Analytic p^n curve, for overlaying on the simulation."""
    n = np.arange(1, max_steps + 1)
    return n, per_step_p ** n
