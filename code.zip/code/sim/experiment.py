"""
Run the full set of experiments and save results/company.json:

E1: the reliability cliff - success rate vs chain length, at several per-step
    accuracies (reproduces the 2026 compounding-error field data).
E2: the fix ladder - how much each architectural change rescues a 10-step,
    85%-per-step process.
E3: where runs die - distribution of the first failing step in a naive chain.
E4: the accuracy you actually need - required per-step accuracy to hit a target
    end-to-end reliability, as chain length grows.
"""
import json, sys, pathlib
import numpy as np

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from sim.company import Architecture, run, naive_curve

TRIALS = 40000


def e1_cliff():
    out = {"steps": list(range(1, 21)), "curves": {}}
    for p in [0.80, 0.85, 0.90, 0.95, 0.99]:
        vals = []
        for n in range(1, 21):
            vals.append(run(Architecture(per_step_p=p, n_steps=n), trials=TRIALS, seed=10 + n)["success_rate"])
        out["curves"][str(p)] = vals
    return out


def e2_fixes():
    scen = [
        ("Naive 10-step chain", Architecture(per_step_p=0.85, n_steps=10)),
        ("+ Human gates (3)", Architecture(per_step_p=0.85, n_steps=10, human_gates=3, human_catch=0.95)),
        ("+ Verification pass", Architecture(per_step_p=0.85, n_steps=10, retries=1, verify_catch=0.7)),
        ("+ Checkpoint & retry", Architecture(per_step_p=0.85, n_steps=10, retries=2, verify_catch=0.9)),
        ("+ Everything combined", Architecture(per_step_p=0.85, n_steps=10, retries=2, verify_catch=0.9, human_gates=2)),
    ]
    return [{"name": nm, "success": run(a, trials=TRIALS, seed=7)["success_rate"]} for nm, a in scen]


def e3_where_die():
    r = run(Architecture(per_step_p=0.85, n_steps=10), trials=TRIALS, seed=3)
    ff = r["first_fail_step"]
    dist = [int(np.sum(ff == s)) for s in range(1, 11)]
    survived = int(np.sum(ff == -1))
    return {"fail_at_step": dist, "survived": survived, "total": TRIALS}


def e4_required_accuracy():
    # per-step accuracy needed for 95% and 99% end-to-end, vs chain length
    steps = list(range(1, 21))
    out = {"steps": steps}
    for target in [0.95, 0.99]:
        out[str(target)] = [target ** (1.0 / n) for n in steps]
    return out


def main():
    data = {"e1_cliff": e1_cliff(), "e2_fixes": e2_fixes(),
            "e3_where_die": e3_where_die(), "e4_required": e4_required_accuracy()}
    (ROOT / "results").mkdir(exist_ok=True)
    json.dump(data, open(ROOT / "results/company.json", "w"), indent=2)

    print("E1 reliability cliff (85% per step):")
    c = data["e1_cliff"]["curves"]["0.85"]
    for n in (1, 3, 5, 10, 15, 20):
        print(f"   {n:2d} steps -> {c[n-1]:.0%}")
    print("\nE2 the fix ladder (10-step, 85%):")
    for f in data["e2_fixes"]:
        print(f"   {f['name']:26s} {f['success']:.0%}")
    print("\nE4 per-step accuracy needed for 95% end-to-end:")
    for n in (5, 10, 20):
        print(f"   {n:2d} steps -> {data['e4_required']['0.95'][n-1]:.1%} per step")


if __name__ == "__main__":
    main()
